import React from "react";
import Link from "@mui/material/Link";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import "./Signup.css";

function SignUp() {
  return (
    // <div className={"screen__content signup"}>
    //   <h1 className={"main-heading"}>Sign Up</h1>
    //   <Box
    //     component="form"
    //     sx={{
    //       "& > :not(style)": { m: 1, width: "30.4ch" },
    //     }}
    //     noValidate
    //     autoComplete="off"
    //   >
    //     <TextField
    //       required
    //       id="outlined-required"
    //       label="First Name"
    //       placeholder="First Name"
    //     />
    //     <TextField
    //       required
    //       id="outlined-required"
    //       label="Last Name"
    //       placeholder="Last Name"
    //     />
    //     <TextField
    //       required
    //       id="outlined-required"
    //       label="Email Address"
    //       placeholder="Email Address"
    //     />
    //     <TextField
    //       required
    //       id="outlined-required"
    //       label="Password"
    //       placeholder="Password"
    //     />
    //   </Box>
    // </div>
      <div className={"screen__content signup"}>
        <h1 className={"main-heading"}>Sign Up</h1>
        <form className={"form"}>
          <div className={"errors"}>Error text</div>
          <div className="flex">
            <div className="field-holder">
              <label className="label">
                First Name <em>*</em>
              </label>
              <input
                className="input"
                type={"text"}
                placeholder={"First Name"}
              />

            </div>
            <div className="field-holder">
              <label className="label">
                Last Name <em>*</em>
              </label>
              <input
                className="input"
                type={"text"}
                placeholder={"Last Name"}
              />
            </div>
          </div>
          <div className="flex">
            <div className="field-holder">
              <label className="label">
                Email Address <em>*</em>
              </label>
              <input
                className="input"
                type={"text"}
                placeholder={"Email Address"}
              />
            </div>
            <div className="field-holder">
              <label className="label">
                Amazon Store ID <em>*</em>
              </label>
              <input
                className="input"
                type={"text"}
                placeholder={"Amazon Store ID"}
              />
            </div>
          </div>
          <div className="flex top">
            <div className="field-holder">
              <label className="label">
                Password <em>*</em>
              </label>
              <input
                className="input"
                type={"password"}
                placeholder={"Password"}
              />
              <div className="optional-txt">
                Password must be at least 07 characters long, containing
                uppercase, lowercase and at least 01 symbol character.
              </div>
            </div>
            <div className="field-holder">
              <label className="label">
                Retype Password <em>*</em>
              </label>
              <input
                className="input"
                type={"password"}
                placeholder={"Retype Password"}
              />
            </div>
          </div>
          <div className="flex">
            <div className="field-holder">
              <label className="label">
                Amazon Associate Email Address{" "}
                <span className="optional">(optional)</span>
              </label>
              <input
                className="input"
                type={"text"}
                placeholder={"Amazon Associate Email Address"}
              />
            </div>
            <div className="field-holder">
              <label className="label">
                Amazon Associate Password{" "}
                <span className="optional">(optional)</span>
              </label>
              <input
                className="input"
                type={"Password"}
                placeholder={"Amazon Associate Password"}
              />
            </div>
          </div>
        </form>
        <div className="forgot-txt">
          <Link to="#">Forgot password?</Link>
        </div>
        <a className="btn">Sign Up</a>
        <div className="text">
          <p>
            Please register
            <Link to="#" className="btn-signup">
              Sign In
            </Link>
          </p>
        </div>
      </div>
  );
}
export default SignUp;
