import React from "react";
import "./Signup.css";
import Link from "@mui/material/Link";

const ForgotPassword = () => {
  return (
    <div className={"screen__content"}>
      <h1 className={"main-heading"}>Forgot password</h1>
      <form className={"form"}>
        <div className={"errors"}>Error text</div>
        <div className="field-holder">
          <label className="label">
            Email Address <em>*</em>
          </label>
          <input
            className="input"
            type={"text"}
            placeholder={"Type your Email"}
          />
        </div>
        <div className="field-holder">
          <label className="label">
            Amazon Store ID <em>*</em>
          </label>
          <input
            className="input"
            type={"text"}
            placeholder={"Amazon Store ID"}
          />
        </div>
      </form>
      <Link className="btn">Submit</Link>
    </div>
  );
};

export default ForgotPassword;
