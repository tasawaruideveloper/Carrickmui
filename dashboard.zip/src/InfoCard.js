import React from 'react';
import Grid from '@mui/material/Grid';
import {
    Card,
    CardContent,
    Typography
} from '@mui/material';

const InfoCard = () => {

    const NewCard = () => {
        return (
            <Card>
                <CardContent>
                    <Typography gutterBottom variant="h5" component="div" textAlign="center">
                        Click
                    </Typography>
                    <Typography variant="h4" color="#5f9cfd" fontWeight="500" textAlign="center">
                        99
                    </Typography>
                </CardContent>
            </Card>
        )
    }

  return (
    <Grid container spacing={2}>
        <Grid item xs={6} sm={3}>
            <NewCard />
        </Grid>
        <Grid item xs={6} sm={3}>
            <NewCard />
        </Grid>
        <Grid item xs={6} sm={3}>
            <NewCard />
        </Grid>
        <Grid item xs={6} sm={3}>
            <NewCard />
        </Grid>
    </Grid>
  )
}

export default InfoCard