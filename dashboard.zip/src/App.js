import "./App.css";

import {
  AppBar,
  Box,
  CssBaseline,
  Divider,
  Drawer,
  Hidden,
  IconButton,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Typography,
  useTheme,
  Collapse,
} from "@mui/material";

import MenuIcon from "@mui/icons-material/Menu";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import InboxIcon from "@mui/icons-material/MoveToInbox";
import MailIcon from "@mui/icons-material/Mail";
import IconExpandLess from "@mui/icons-material/ExpandLess";
import IconExpandMore from "@mui/icons-material/ExpandMore";
import IconLibraryBooks from "@mui/icons-material/LibraryBooks";
import Grid from "@mui/material/Grid";


import { useState } from "react";
import ChartBar from "./ChartBar";
import DataTable from "./DataTable";
import InfoCard from "./InfoCard";
import DateRangePicker from "./DateRangePicker";
import SignUp from "./Signup";
import LogIn from "./LogIn";
import ForgotPassword from "./ForgotPassword";

const App = () => {
  // const { isToggleOn, changeToggle } = props;

  const [isHandleClick, setIsHandleClick] = useState(false);

  const onClickHandler = () => {
    setIsHandleClick(!isHandleClick);
  };

  const theme = useTheme();

  const [open, setOpen] = useState(false);

  const handleDrawerOpen = () => {
    setOpen(true);
  };
  const handleDrawerClose = () => {
    setOpen(false);
  };
  const [openDropDown, setOpenDropDown] = useState(false);

  const handleClick = () => {
    setOpenDropDown(!openDropDown);
  }
  return (
    <>
      <Box sx={{ display: "flex" }}>
        <CssBaseline />
        <div className={`top-header ${open ? "active" : ""}`}>
          <AppBar position="fixed" open={open}>
            <Toolbar>
              <Grid container spacing={2} mb={0}>
                <Grid item xs={9} sm={4}>
                  <div className="d-flex">
                    <IconButton
                      color="inherit"
                      aria-label="open drawer"
                      onClick={handleDrawerOpen}
                      edge="start"
                      sx={{ mr: 2, ...(open && { display: "none" }) }}
                    >
                      <MenuIcon />
                    </IconButton>
                    <Typography variant="h6" noWrap component="div">
                      Carrickui
                    </Typography>
                    <DateRangePicker />
                  </div>
                </Grid>
                <Grid item xs={3} sm={4} textAlign="center">
                  <h1 onClick={onClickHandler}>
                    {isHandleClick ? "Paid" : "unPaid"}
                  </h1>
                </Grid>
                <Grid
                  item
                  xs={Hidden}
                  sm={4}
                  className="xs-hidden"
                  textAlign="center"
                >
                  <input
                    className="input search"
                    type={"search"}
                    placeholder={"Search"}
                  />
                </Grid>
              </Grid>
            </Toolbar>
          </AppBar>
        </div>
        <Drawer
          sx={{
            width: "250px",
            flexShrink: 0,
            "& .MuiDrawer-paper": {
              width: "250px",
              boxSizing: "border-box",
            },
          }}
          variant="persistent"
          anchor="left"
          open={open}
          className={`${open ? "active" : ""}`}
        >
          <div className="drawer-header">
            <IconButton onClick={handleDrawerClose}>
              {theme.direction === "ltr" ? (
                <ChevronLeftIcon />
              ) : (
                <ChevronRightIcon />
              )}
            </IconButton>
          </div>
          <Divider />
          <List>
            {["Inbox", "Starred", "Send email", "Drafts"].map((text, index) => (
              <ListItem button key={text}>
                <ListItemIcon>
                  {index % 2 === 0 ? <InboxIcon /> : <MailIcon />}
                </ListItemIcon>
                <ListItemText primary={text} />
              </ListItem>
            ))}
          </List>
          <Divider />
          <List>
            {["All mail", "Trash", "Spam"].map((text, index) => (
              <ListItem button key={text}>
                <ListItemIcon>
                  {index % 2 === 0 ? <InboxIcon /> : <MailIcon />}
                </ListItemIcon>
                <ListItemText primary={text} />
              </ListItem>
            ))}
          </List>
          <ListItem button onClick={handleClick}>
            <ListItemIcon>
              <IconLibraryBooks />
            </ListItemIcon>
            <ListItemText primary="Nested Pages" />
            {openDropDown ? <IconExpandLess /> : <IconExpandMore />}
          </ListItem>
          <Collapse in={openDropDown} timeout="auto" unmountOnExit>
            <Divider />
            <List component="div" disablePadding>
              <ListItem button>
                <ListItemText inset primary="Nested Page 1" />
              </ListItem>
              <ListItem button>
                <ListItemText inset primary="Nested Page 2" />
              </ListItem>
            </List>
          </Collapse>
        </Drawer>
        <div className={`main ${open ? "active" : ""}`} open={open}>
          <InfoCard />
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <ChartBar />
            </Grid>
            <Grid item xs={12} sm={6}>
              <DataTable />
            </Grid>
            <Grid item xs={12} sm={6}>
              <ChartBar />
            </Grid>
            <Grid item xs={12} sm={6}>
              <DataTable />
            </Grid>
          </Grid>
        </div>
      </Box>
      {/* <SignUp />
        <ForgotPassword />
        <LogIn />*/}
    </>
  );
};
export default App;
