import React from 'react';
import Link from "@mui/material/Link";
import "./Signup.css";

const LogIn = () => {
  return (
    <div className={'screen__content'}>
            <h1 className={'main-heading'}>Please Login</h1>
            <form className={'form'}>
                <div className={'errors'}>
                    Error text
                </div>
                <div className="field-holder">
                    <label className="label">
                    Email <em>*</em>
                    </label>
                    <input
                    className="input"
                    type={'text'}
                    placeholder={'Type your username'}
                    />
                </div>
                <div className="field-holder">
                    <label className="label">
                    Password <em>*</em>
                    </label>
                    <input
                    className="input"
                    type={'password'}
                    placeholder={'Type your username'}
                    />
                </div>
            </form>
            <div className="forgot-txt">
                <Link to="#">Forgot password?</Link>
            </div>
            <a className="btn">Sign In</a>
            <div className="text">
                <p>Please register 
                    <Link to="#" className="btn-signup">
                        Sign Up
                    </Link>
                </p>
            </div>
        </div>
  )
}

export default LogIn